import React, { createContext, useContext, useState, ReactNode } from 'react';
import { ConfigurationState, MotorcycleBrand, MotorcycleModel, ColorScheme, Inspiration } from '../types';
import { mockGeneratedImages } from '../data/mockData';

interface ConfiguratorContextType {
  config: ConfigurationState;
  setStep: (step: number) => void;
  setBrand: (brand: MotorcycleBrand | null) => void;
  setModel: (model: MotorcycleModel | null) => void;
  setColorScheme: (colorScheme: ColorScheme | null) => void;
  setInspiration: (inspiration: Inspiration | null) => void;
  setCustomImage: (image: string | null) => void;
  setPrompt: (prompt: string) => void;
  generatePreview: () => void;
  selectAlternativePreview: (index: number) => void;
  resetConfig: () => void;
  isStepComplete: (step: number) => boolean;
  isStepAccessible: (step: number) => boolean;
}

const initialState: ConfigurationState = {
  step: 1,
  brand: null,
  model: null,
  colorScheme: null,
  inspiration: null,
  customImage: null,
  prompt: '',
  generatedPreview: null,
  alternativePreview: []
};

const ConfiguratorContext = createContext<ConfiguratorContextType | undefined>(undefined);

export const ConfiguratorProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [config, setConfig] = useState<ConfigurationState>(initialState);

  const setStep = (step: number) => {
    setConfig(prev => ({ ...prev, step }));
  };

  const setBrand = (brand: MotorcycleBrand | null) => {
    setConfig(prev => ({ 
      ...prev, 
      brand,
      model: brand ? prev.model && prev.model.brandId === brand.id ? prev.model : null : null
    }));
  };

  const setModel = (model: MotorcycleModel | null) => {
    setConfig(prev => ({ 
      ...prev, 
      model,
      generatedPreview: model?.image || null 
    }));
  };

  const setColorScheme = (colorScheme: ColorScheme | null) => {
    setConfig(prev => ({ ...prev, colorScheme }));
  };

  const setInspiration = (inspiration: Inspiration | null) => {
    setConfig(prev => ({ 
      ...prev, 
      inspiration,
      generatedPreview: inspiration?.image || null 
    }));
  };

  const setCustomImage = (customImage: string | null) => {
    setConfig(prev => ({ 
      ...prev, 
      customImage,
      inspiration: null,
      generatedPreview: customImage 
    }));
  };

  const setPrompt = (prompt: string) => {
    setConfig(prev => ({ ...prev, prompt }));
  };

  const generatePreview = () => {
    setConfig(prev => ({
      ...prev,
      generatedPreview: mockGeneratedImages[0],
      alternativePreview: mockGeneratedImages.slice(1)
    }));
  };

  const selectAlternativePreview = (index: number) => {
    setConfig(prev => {
      if (!prev.generatedPreview || index >= prev.alternativePreview.length) return prev;
      
      const newMain = prev.alternativePreview[index];
      const newAlternatives = [...prev.alternativePreview];
      newAlternatives[index] = prev.generatedPreview;
      
      return {
        ...prev,
        generatedPreview: newMain,
        alternativePreview: newAlternatives
      };
    });
  };

  const resetConfig = () => {
    setConfig(initialState);
  };

  const isStepComplete = (step: number): boolean => {
    switch (step) {
      case 1: return config.brand !== null;
      case 2: return config.model !== null;
      case 3: return config.inspiration !== null || config.customImage !== null;
      case 4: return config.colorScheme !== null;
      case 5: return true; // Prompt is optional
      default: return false;
    }
  };

  const isStepAccessible = (step: number): boolean => {
    if (step === 1) return true;
    
    for (let i = 1; i < step; i++) {
      if (!isStepComplete(i)) return false;
    }
    
    return true;
  };

  return (
    <ConfiguratorContext.Provider
      value={{
        config,
        setStep,
        setBrand,
        setModel,
        setColorScheme,
        setInspiration,
        setCustomImage,
        setPrompt,
        generatePreview,
        selectAlternativePreview,
        resetConfig,
        isStepComplete,
        isStepAccessible
      }}
    >
      {children}
    </ConfiguratorContext.Provider>
  );
};

export const useConfigurator = (): ConfiguratorContextType => {
  const context = useContext(ConfiguratorContext);
  if (context === undefined) {
    throw new Error('useConfigurator must be used within a ConfiguratorProvider');
  }
  return context;
};