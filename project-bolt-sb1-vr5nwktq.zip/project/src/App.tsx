import React from 'react';
import { ConfiguratorProvider } from './context/ConfiguratorContext';
import MainLayout from './components/layout/MainLayout';

function App() {
  return (
    <ConfiguratorProvider>
      <MainLayout />
    </ConfiguratorProvider>
  );
}

export default App;