import { MotorcycleBrand, MotorcycleModel, ColorScheme, Inspiration } from '../types';

export const motorcycleBrands: MotorcycleBrand[] = [
  {
    id: 1,
    name: 'Yamaha',
    logo: 'https://images.pexels.com/photos/2116475/pexels-photo-2116475.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 2,
    name: 'Honda',
    logo: 'https://images.pexels.com/photos/1119796/pexels-photo-1119796.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 3,
    name: 'Kawasaki',
    logo: 'https://images.pexels.com/photos/163210/motorcycle-racer-racing-race-163210.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 4,
    name: 'Suzuki',
    logo: 'https://images.pexels.com/photos/1413412/pexels-photo-1413412.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 5,
    name: 'KTM',
    logo: 'https://images.pexels.com/photos/2393835/pexels-photo-2393835.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  }
];

export const motorcycleModels: MotorcycleModel[] = [
  {
    id: 1,
    name: 'Tenere 700',
    brandId: 1,
    image: 'https://images.pexels.com/photos/2119714/pexels-photo-2119714.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 2,
    name: 'MT-09',
    brandId: 1,
    image: 'https://images.pexels.com/photos/2611690/pexels-photo-2611690.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 3,
    name: 'Africa Twin',
    brandId: 2,
    image: 'https://images.pexels.com/photos/1715193/pexels-photo-1715193.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 4,
    name: 'CBR1000RR',
    brandId: 2,
    image: 'https://images.pexels.com/photos/2393821/pexels-photo-2393821.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 5,
    name: 'Ninja H2',
    brandId: 3,
    image: 'https://images.pexels.com/photos/210117/pexels-photo-210117.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 6,
    name: 'Z900',
    brandId: 3,
    image: 'https://images.pexels.com/photos/1413412/pexels-photo-1413412.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 7,
    name: 'GSX-R1000',
    brandId: 4,
    image: 'https://images.pexels.com/photos/258092/pexels-photo-258092.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 8,
    name: 'V-Strom 1050',
    brandId: 4,
    image: 'https://images.pexels.com/photos/995487/pexels-photo-995487.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 9,
    name: '1290 Super Adventure',
    brandId: 5,
    image: 'https://images.pexels.com/photos/39693/motorcycle-racer-racing-race-39693.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 10,
    name: '450 EXC',
    brandId: 5,
    image: 'https://images.pexels.com/photos/818487/pexels-photo-818487.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  }
];

export const colorSchemes: ColorScheme[] = [
  {
    id: 1,
    name: 'Racing Blue',
    background: '#003366',
    foreground: '#FFFFFF',
    accent: '#33CCFF'
  },
  {
    id: 2,
    name: 'Desert Storm',
    background: '#E8D6B3',
    foreground: '#6D4C3D',
    accent: '#FF7D00'
  },
  {
    id: 3,
    name: 'Electric Green',
    background: '#222222',
    foreground: '#EEEEEE',
    accent: '#39FF14'
  },
  {
    id: 4,
    name: 'Fire Red',
    background: '#700000',
    foreground: '#FFFFFF',
    accent: '#FF3A00'
  },
  {
    id: 5,
    name: 'Urban Camo',
    background: '#666666',
    foreground: '#CCCCCC',
    accent: '#333333'
  },
  {
    id: 6,
    name: 'Sunset Orange',
    background: '#003F5C',
    foreground: '#FFA600',
    accent: '#FF5E78'
  }
];

export const inspirations: Inspiration[] = [
  {
    id: 1,
    title: 'Desert Rally',
    modelId: 1,
    image: 'https://images.pexels.com/photos/1061139/pexels-photo-1061139.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 2,
    title: 'Urban Street',
    modelId: 2,
    image: 'https://images.pexels.com/photos/1595437/pexels-photo-1595437.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 3,
    title: 'Adventure Racing',
    modelId: 3,
    image: 'https://images.pexels.com/photos/1309430/pexels-photo-1309430.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 4,
    title: 'Track Beast',
    modelId: 4,
    image: 'https://images.pexels.com/photos/1045535/pexels-photo-1045535.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 5,
    title: 'Speed Demon',
    modelId: 5,
    image: 'https://images.pexels.com/photos/39693/motorcycle-racer-racing-race-39693.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 6,
    title: 'City Ninja',
    modelId: 6,
    image: 'https://images.pexels.com/photos/2519374/pexels-photo-2519374.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  }
];

export const mockGeneratedImages = [
  'https://images.pexels.com/photos/1413412/pexels-photo-1413412.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
  'https://images.pexels.com/photos/2116475/pexels-photo-2116475.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
  'https://images.pexels.com/photos/258092/pexels-photo-258092.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
  'https://images.pexels.com/photos/1119796/pexels-photo-1119796.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
];