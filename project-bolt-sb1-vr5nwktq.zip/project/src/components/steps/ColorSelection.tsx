import React from 'react';
import { useConfigurator } from '../../context/ConfiguratorContext';
import { colorSchemes } from '../../data/mockData';

const ColorSelection: React.FC = () => {
  const { config, setColorScheme } = useConfigurator();
  
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Choisis tes couleurs</h2>
      <p className="text-gray-600">Sélectionne un schéma de couleurs pour ton kit déco</p>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
        {colorSchemes.map((scheme) => (
          <div 
            key={scheme.id}
            onClick={() => setColorScheme(scheme)}
            className={`
              p-4 rounded-lg border-2 cursor-pointer transition-all
              ${config.colorScheme?.id === scheme.id 
                ? 'border-blue-500 shadow-md transform scale-[1.02]' 
                : 'border-gray-200 hover:border-blue-300'
              }
            `}
          >
            <h3 className="font-medium mb-2">{scheme.name}</h3>
            <div className="flex space-x-2">
              <div 
                className="w-10 h-10 rounded-md border border-gray-200" 
                style={{ backgroundColor: scheme.background }}
                title="Arrière-plan"
              ></div>
              <div 
                className="w-10 h-10 rounded-md border border-gray-200" 
                style={{ backgroundColor: scheme.foreground }}
                title="Premier plan"
              ></div>
              <div 
                className="w-10 h-10 rounded-md border border-gray-200" 
                style={{ backgroundColor: scheme.accent }}
                title="Accent"
              ></div>
            </div>
            <div className="mt-3 p-3 rounded-md" style={{ 
              backgroundColor: scheme.background,
              color: scheme.foreground
            }}>
              <div className="flex justify-between items-center">
                <span>Aperçu</span>
                <span style={{ color: scheme.accent }}>●</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ColorSelection;