import React from 'react';
import { useConfigurator } from '../../context/ConfiguratorContext';
import { motorcycleModels } from '../../data/mockData';

const ModelSelection: React.FC = () => {
  const { config, setModel } = useConfigurator();
  
  // Filter models based on selected brand
  const filteredModels = config.brand 
    ? motorcycleModels.filter(model => model.brandId === config.brand.id)
    : [];
  
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Choisis ton modèle</h2>
      <p className="text-gray-600">Sélectionne le modèle de ta {config.brand?.name}</p>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
        {filteredModels.map((model) => (
          <div 
            key={model.id}
            onClick={() => setModel(model)}
            className={`
              rounded-lg border-2 cursor-pointer overflow-hidden transition-all
              ${config.model?.id === model.id 
                ? 'border-blue-500 shadow-md transform scale-[1.02]' 
                : 'border-gray-200 hover:border-blue-300'
              }
            `}
          >
            {model.image && (
              <div className="h-32 bg-gray-100">
                <img 
                  src={model.image} 
                  alt={model.name} 
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            <div className="p-4">
              <h3 className="font-medium">{model.name}</h3>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ModelSelection;