import React from 'react';
import { useConfigurator } from '../../context/ConfiguratorContext';

const PromptInput: React.FC = () => {
  const { config, setPrompt } = useConfigurator();
  
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Personnalise ton kit</h2>
      <p className="text-gray-600">Ajoute des détails spécifiques pour ton kit déco (numéro de course, nom, etc.)</p>
      
      <div className="mt-4">
        <textarea
          value={config.prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Ex: Je veux le numéro 23 en grand sur les côtés, mon nom 'MARTIN' en petit sous le numéro, et un design inspiré des couleurs de course classiques..."
          className="w-full h-32 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
        />
      </div>
      
      <div className="mt-4">
        <h3 className="font-medium mb-2">Suggestions :</h3>
        <div className="space-y-2">
          {[
            "Numéro de course sur les côtés",
            "Nom du pilote sous le numéro",
            "Logo des sponsors",
            "Design racing stripes",
            "Style motocross classique"
          ].map((suggestion, index) => (
            <button
              key={index}
              onClick={() => setPrompt(prev => prev ? `${prev}\n${suggestion}` : suggestion)}
              className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-md transition-colors"
            >
              + {suggestion}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PromptInput;