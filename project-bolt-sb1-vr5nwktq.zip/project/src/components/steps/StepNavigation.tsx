import React from 'react';
import { useConfigurator } from '../../context/ConfiguratorContext';
import { 
  Factory, 
  Bike, 
  Palette, 
  Images, 
  MessageSquareText,
  CheckCircle2,
  ChevronRight
} from 'lucide-react';

interface StepNavigationProps {
  onStepClick: () => void;
}

const StepNavigation: React.FC<StepNavigationProps> = ({ onStepClick }) => {
  const { config, setStep, isStepComplete, isStepAccessible } = useConfigurator();
  
  const steps = [
    { id: 1, name: 'Marque', icon: <Factory size={20} /> },
    { id: 2, name: 'Modèle', icon: <Bike size={20} /> },
    { id: 3, name: 'Inspirations', icon: <Images size={20} /> },
    { id: 4, name: 'Couleurs', icon: <Palette size={20} /> },
    { id: 5, name: 'Prompt', icon: <MessageSquareText size={20} /> },
  ];

  const handleStepClick = (stepId: number) => {
    if (isStepAccessible(stepId)) {
      setStep(stepId);
      onStepClick();
    }
  };

  return (
    <div className="space-y-2">
      {steps.map((step) => {
        const isActive = config.step === step.id;
        const isCompleted = isStepComplete(step.id);
        const isAccessible = isStepAccessible(step.id);
        
        return (
          <button
            key={step.id}
            onClick={() => handleStepClick(step.id)}
            disabled={!isAccessible}
            className={`
              w-full flex items-center justify-between p-4 rounded-lg transition-all
              ${isActive ? 'bg-blue-50 border border-blue-200' : 'bg-white border border-gray-200'} 
              ${isAccessible ? 'hover:bg-gray-50 cursor-pointer' : 'opacity-60 cursor-not-allowed'}
            `}
          >
            <div className="flex items-center">
              <div className={`
                p-2 rounded-full mr-3
                ${isCompleted ? 'text-green-600 bg-green-100' : 'text-gray-600 bg-gray-100'}
              `}>
                {isCompleted ? <CheckCircle2 size={20} /> : step.icon}
              </div>
              <span className="font-medium">{step.name}</span>
            </div>
            
            <div>
              <ChevronRight size={20} className="text-gray-400" />
            </div>
          </button>
        );
      })}
    </div>
  );
}

export default StepNavigation