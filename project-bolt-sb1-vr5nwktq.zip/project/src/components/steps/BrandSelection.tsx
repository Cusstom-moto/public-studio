import React from 'react';
import { useConfigurator } from '../../context/ConfiguratorContext';
import { motorcycleBrands } from '../../data/mockData';

const BrandSelection: React.FC = () => {
  const { config, setBrand } = useConfigurator();
  
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Choisis ta marque de moto</h2>
      <p className="text-gray-600">Sélectionne la marque de ta moto pour commencer la personnalisation</p>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
        {motorcycleBrands.map((brand) => (
          <div 
            key={brand.id}
            onClick={() => setBrand(brand)}
            className={`
              p-4 rounded-lg border-2 cursor-pointer transition-all
              ${config.brand?.id === brand.id 
                ? 'border-blue-500 bg-blue-50 shadow-md transform scale-[1.02]' 
                : 'border-gray-200 hover:border-blue-300 hover:bg-gray-50'
              }
            `}
          >
            <div className="flex items-center">
              {brand.logo && (
                <div className="w-16 h-16 rounded-full overflow-hidden mr-4 bg-gray-100">
                  <img 
                    src={brand.logo} 
                    alt={`${brand.name} logo`} 
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
              <h3 className="text-lg font-medium">{brand.name}</h3>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BrandSelection;