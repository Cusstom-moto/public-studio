import React from 'react';
import { useConfigurator } from '../../context/ConfiguratorContext';
import { inspirations } from '../../data/mockData';
import { Upload } from 'lucide-react';

interface InspirationGalleryProps {
  onSelect: () => void;
}

const InspirationGallery: React.FC<InspirationGalleryProps> = ({ onSelect }) => {
  const { config, setInspiration, setCustomImage } = useConfigurator();
  
  const filteredInspirations = config.model 
    ? inspirations.filter(insp => insp.modelId === config.model.id)
    : inspirations;

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const imageUrl = reader.result as string;
        setCustomImage(imageUrl);
        onSelect();
      };
      reader.readAsDataURL(file);
    }
  };
  
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Galerie d'inspirations</h2>
      <p className="text-gray-600">Choisis un design qui t'inspire ou upload ta propre image</p>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
        {/* Upload Card */}
        <div className="relative rounded-lg border-2 border-dashed border-gray-300 p-4 hover:border-blue-500 transition-colors cursor-pointer">
          <input
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          <div className="flex flex-col items-center justify-center h-40">
            <Upload size={40} className="text-gray-400 mb-2" />
            <p className="text-sm text-gray-600">Upload ton image</p>
          </div>
        </div>

        {filteredInspirations.map((item) => (
          <div 
            key={item.id}
            onClick={() => {
              setInspiration(item);
              onSelect();
            }}
            className={`
              rounded-lg border-2 cursor-pointer overflow-hidden transition-all
              ${config.inspiration?.id === item.id 
                ? 'border-blue-500 shadow-md transform scale-[1.02]' 
                : 'border-gray-200 hover:border-blue-300'
              }
            `}
          >
            <div className="h-40 bg-gray-100">
              <img 
                src={item.image} 
                alt={item.title} 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-4">
              <h3 className="font-medium">{item.title}</h3>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default InspirationGallery;