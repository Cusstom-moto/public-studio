import React, { useEffect, useState } from 'react';

interface ProgressBarProps {
  currentStep: number;
  totalSteps: number;
  colors: string[];
}

const ProgressBar: React.FC<ProgressBarProps> = ({ currentStep, totalSteps, colors }) => {
  const [width, setWidth] = useState(0);
  
  useEffect(() => {
    // Animate progress bar width on step change
    const progress = (currentStep / totalSteps) * 100;
    
    // Small delay for animation effect
    const timer = setTimeout(() => {
      setWidth(progress);
    }, 100);
    
    return () => clearTimeout(timer);
  }, [currentStep, totalSteps]);

  // Create gradient from provided colors
  const gradientStyle = {
    background: `linear-gradient(to right, ${colors.join(', ')})`,
    width: `${width}%`,
    transition: 'width 0.5s ease-in-out'
  };

  return (
    <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
      <div 
        className="h-full rounded-full" 
        style={gradientStyle}
      ></div>
    </div>
  );
};

export default ProgressBar;