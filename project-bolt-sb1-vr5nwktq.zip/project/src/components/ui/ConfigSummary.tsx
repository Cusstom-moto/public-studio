import React from 'react';
import { useConfigurator } from '../../context/ConfiguratorContext';

const ConfigSummary: React.FC = () => {
  const { config } = useConfigurator();
  const { brand, model, colorScheme, inspiration } = config;

  if (!brand && !model && !colorScheme && !inspiration) {
    return (
      <div className="border border-gray-200 rounded-lg p-4 mt-4">
        <h3 className="font-medium text-gray-700 mb-2">Détails de ta configuration</h3>
        <p className="text-gray-500 text-sm">
          Les détails de ta configuration s'afficheront ici au fur et à mesure de tes choix.
        </p>
      </div>
    );
  }

  return (
    <div className="border border-gray-200 rounded-lg p-4 mt-4">
      <h3 className="font-medium text-gray-700 mb-2">Détails de ta configuration</h3>
      <div className="flex flex-wrap gap-2">
        {brand && (
          <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
            {brand.name}
          </span>
        )}
        
        {model && (
          <span className="bg-purple-100 text-purple-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
            {model.name}
          </span>
        )}
        
        {colorScheme && (
          <div className="flex items-center">
            <span className="bg-gray-100 text-gray-800 text-xs font-medium px-2.5 py-0.5 rounded-full mr-1">
              {colorScheme.name}
            </span>
            <div className="flex">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: colorScheme.background }}></div>
              <div className="w-3 h-3 rounded-full mx-0.5" style={{ backgroundColor: colorScheme.foreground }}></div>
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: colorScheme.accent }}></div>
            </div>
          </div>
        )}
        
        {inspiration && (
          <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
            {inspiration.title}
          </span>
        )}
        
        {config.customImage && (
          <span className="bg-yellow-100 text-yellow-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
            Image personnalisée
          </span>
        )}
        
        {config.prompt && (
          <span className="bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
            Prompt personnalisé
          </span>
        )}
      </div>
    </div>
  );
};

export default ConfigSummary;