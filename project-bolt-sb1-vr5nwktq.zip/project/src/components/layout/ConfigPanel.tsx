import React, { useState } from 'react';
import { useConfigurator } from '../../context/ConfiguratorContext';
import StepNavigation from '../steps/StepNavigation';
import ProgressBar from '../ui/ProgressBar';
import BrandSelection from '../steps/BrandSelection';
import ModelSelection from '../steps/ModelSelection';
import ColorSelection from '../steps/ColorSelection';
import InspirationGallery from '../steps/InspirationGallery';
import PromptInput from '../steps/PromptInput';
import { ArrowLeft } from 'lucide-react';

const ConfigPanel: React.FC = () => {
  const { config, setStep, generatePreview } = useConfigurator();
  const [isFullscreen, setIsFullscreen] = useState(false);

  const renderStepContent = () => {
    switch (config.step) {
      case 1: return <BrandSelection onSelect={() => setIsFullscreen(false)} />;
      case 2: return <ModelSelection onSelect={() => setIsFullscreen(false)} />;
      case 3: return <InspirationGallery onSelect={() => setIsFullscreen(false)} />;
      case 4: return <ColorSelection onSelect={() => setIsFullscreen(false)} />;
      case 5: return <PromptInput onSelect={() => setIsFullscreen(false)} />;
      default: return null;
    }
  };

  const handleBackClick = () => {
    setIsFullscreen(false);
  };

  const isReadyToGenerate = config.isStepComplete && 
    [1, 2, 3, 4].every(step => config.isStepComplete(step));

  return (
    <div className={`bg-white rounded-lg shadow-lg m-2 flex flex-col ${isFullscreen ? 'md:w-full' : 'md:w-2/5'} transition-all duration-300 ease-in-out`}>
      <div className="sticky top-0 p-4 bg-white z-10 rounded-t-lg">
        <h1 className="text-2xl font-bold text-left mb-4">Crée ton kit déco personnalisé</h1>
        <ProgressBar 
          currentStep={config.step} 
          totalSteps={5} 
          colors={["#4f46e5", "#7c3aed", "#6366f1"]} 
        />
      </div>
      
      <div className="flex-grow overflow-y-auto p-4">
        {isFullscreen ? (
          <div>
            <button 
              onClick={handleBackClick}
              className="flex items-center mb-4 text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft size={20} className="mr-2" />
              Retour
            </button>
            {renderStepContent()}
          </div>
        ) : (
          <>
            <StepNavigation onStepClick={() => setIsFullscreen(true)} />
            {isReadyToGenerate && (
              <button
                onClick={generatePreview}
                className="w-full mt-4 px-6 py-3 rounded-full font-medium text-white bg-gradient-to-r from-[#4f46e5] via-[#7c3aed] to-[#6366f1] hover:opacity-90 transform hover:scale-105 transition-all"
              >
                Générer mon image IA
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default ConfigPanel;