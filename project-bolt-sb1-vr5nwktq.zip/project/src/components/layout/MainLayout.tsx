import React from 'react';
import ConfigPanel from './ConfigPanel';
import PreviewPanel from './PreviewPanel';

const MainLayout: React.FC = () => {
  return (
    <div className="flex flex-col md:flex-row h-screen w-screen bg-gray-100 overflow-hidden">
      <ConfigPanel />
      <PreviewPanel />
    </div>
  );
};

export default MainLayout;