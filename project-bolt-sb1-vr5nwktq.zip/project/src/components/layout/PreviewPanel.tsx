import React from 'react';
import { useConfigurator } from '../../context/ConfiguratorContext';
import ConfigSummary from '../ui/ConfigSummary';

const PreviewPanel: React.FC = () => {
  const { config, selectAlternativePreview } = useConfigurator();
  const { generatedPreview, alternativePreview } = config;

  return (
    <div className="bg-white rounded-lg shadow-lg m-2 p-6 flex flex-col md:w-3/5">
      <div className="flex-grow flex flex-col">
        <div className="relative bg-gray-100 rounded-lg h-[50vh] flex items-center justify-center mb-4">
          {generatedPreview ? (
            <img 
              src={generatedPreview} 
              alt="Preview" 
              className="max-h-full max-w-full object-contain rounded-lg" 
            />
          ) : (
            <div className="text-center p-6">
              <p className="text-gray-500 mb-4">Ta prévisualisation s'affichera ici après génération</p>
            </div>
          )}
        </div>
        
        {generatedPreview && alternativePreview.length > 0 && (
          <div className="flex space-x-3 my-3 overflow-x-auto pb-2">
            {alternativePreview.map((preview, index) => (
              <img 
                key={index}
                src={preview}
                alt={`Alternative ${index + 1}`}
                className="h-20 w-20 object-cover rounded-md cursor-pointer hover:ring-2 hover:ring-blue-500 transition-all"
                onClick={() => selectAlternativePreview(index)}
              />
            ))}
          </div>
        )}
        
        <ConfigSummary />
      </div>
    </div>
  );
};

export default PreviewPanel;