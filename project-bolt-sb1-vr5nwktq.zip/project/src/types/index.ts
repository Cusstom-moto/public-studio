export interface MotorcycleBrand {
  id: number;
  name: string;
  logo?: string;
}

export interface MotorcycleModel {
  id: number;
  name: string;
  brandId: number;
  image?: string;
}

export interface ColorScheme {
  id: number;
  name: string;
  background: string;
  foreground: string;
  accent: string;
}

export interface Inspiration {
  id: number;
  title: string;
  modelId: number;
  image: string;
}

export interface ConfigurationState {
  step: number;
  brand: MotorcycleBrand | null;
  model: MotorcycleModel | null;
  colorScheme: ColorScheme | null;
  inspiration: Inspiration | null;
  customImage: string | null;
  prompt: string;
  generatedPreview: string | null;
  alternativePreview: string[];
}